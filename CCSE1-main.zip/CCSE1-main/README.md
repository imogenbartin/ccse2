# CCSE1
# pip install -r requirements.txt
# run main.py in a python IDE to run the website

