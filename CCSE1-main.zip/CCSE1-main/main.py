from Website import createApp #importing the function from __init__.py


app = createApp()


if __name__ == '__main__':
    app.run(debug=True)